package org.bonitasoft.connector;

import org.bonitasoft.engine.connector.AbstractConnector;
import org.bonitasoft.engine.connector.ConnectorValidationException;

public abstract class AbstractCustomJasperImpl extends AbstractConnector {

	protected final static String DBDRIVER_INPUT_PARAMETER = "dbDriver";
	protected final static String JDBCURL_INPUT_PARAMETER = "jdbcUrl";
	protected final static String USER_INPUT_PARAMETER = "user";
	protected final static String PASSWORD_INPUT_PARAMETER = "password";
	protected final static String JRXMLDOCUMENT_INPUT_PARAMETER = "jrxmlDocument";
	protected final static String PARAMETERS_INPUT_PARAMETER = "parameters";
	protected final static String OUTPUTFORMAT_INPUT_PARAMETER = "outputFormat";
	protected final String REPORTDOCVALUE_OUTPUT_PARAMETER = "reportDocValue";

	protected final java.lang.String getDbDriver() {
		return (java.lang.String) getInputParameter(DBDRIVER_INPUT_PARAMETER);
	}

	protected final java.lang.String getJdbcUrl() {
		return (java.lang.String) getInputParameter(JDBCURL_INPUT_PARAMETER);
	}

	protected final java.lang.String getUser() {
		return (java.lang.String) getInputParameter(USER_INPUT_PARAMETER);
	}

	protected final java.lang.String getPassword() {
		return (java.lang.String) getInputParameter(PASSWORD_INPUT_PARAMETER);
	}

	protected final java.lang.String getJrxmlDocument() {
		return (java.lang.String) getInputParameter(JRXMLDOCUMENT_INPUT_PARAMETER);
	}

	protected final java.util.List getParameters() {
		return (java.util.List) getInputParameter(PARAMETERS_INPUT_PARAMETER);
	}

	protected final java.lang.String getOutputFormat() {
		return (java.lang.String) getInputParameter(OUTPUTFORMAT_INPUT_PARAMETER);
	}

	protected final void setReportDocValue(
			org.bonitasoft.engine.bpm.document.DocumentValue reportDocValue) {
		setOutputParameter(REPORTDOCVALUE_OUTPUT_PARAMETER, reportDocValue);
	}

	@Override
	public void validateInputParameters() throws ConnectorValidationException {
		try {
			getDbDriver();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("dbDriver type is invalid");
		}
		try {
			getJdbcUrl();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("jdbcUrl type is invalid");
		}
		try {
			getUser();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("user type is invalid");
		}
		try {
			getPassword();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("password type is invalid");
		}
		try {
			getJrxmlDocument();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException(
					"jrxmlDocument type is invalid");
		}
		try {
			getParameters();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("parameters type is invalid");
		}
		try {
			getOutputFormat();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException(
					"outputFormat type is invalid");
		}

	}

}
